package com.prometheous.prometheus.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrometheusDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
