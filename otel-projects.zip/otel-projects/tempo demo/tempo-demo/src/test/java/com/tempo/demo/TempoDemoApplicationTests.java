package com.tempo.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TempoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
