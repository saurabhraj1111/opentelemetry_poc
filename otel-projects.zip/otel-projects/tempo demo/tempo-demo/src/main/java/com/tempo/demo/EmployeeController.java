package com.tempo.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/employee")
//@Slf4j
public class EmployeeController {
	private static final Logger log = (Logger) LoggerFactory.getLogger(EmployeeController.class);

	
	
	@RequestMapping("/get")
	public String get() {

		RestTemplate restTemplate=new RestTemplate();
		log.info("=========Tempo log=======");
		ResponseEntity<String> responseEntity = restTemplate.getForEntity("http://localhost:9191/employee/get", String.class);
		return responseEntity.getBody();
	}

}
